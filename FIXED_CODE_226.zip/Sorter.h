#pragma once
//The Sorter interface and any of it's decendent DO NOT OWN the containers they are asked to sort
//It is the complete responsibility of the calling code to ensure the pointers they hold are valid 


//Interface for different sorting algorithm
//It holds a pointer to a Random_Access_Container that gaurntees a .size() method and an indexing operator
//The elements of the container must support all relational operators, a copy constructor and a cout<< operator
template<typename Random_Access_Container>
class Sorter
{
protected:
	Random_Access_Container* list;

public:
	Sorter(Random_Access_Container*);
	virtual void run() = 0;
};
/////////////////////////////////////
////////////////////////////////////
///////////////////////////////////



/* Actual sorting algorithms declarations */


template<typename T> 
class Insertion_Sorter : public Sorter<T> {
public :
	Insertion_Sorter(T*);
	void run();
};

template<typename T>
class Selection_Sorter : public Sorter<T> {
public :
	Selection_Sorter(T*);
	void run(); 
};

template<typename T>
class Merge_Sorter : public Sorter<T> {
	//The helper that actually does all the work, .run() can't becuase it doesn't take any argument so it can't keep track of subarrays
	static void merge_sort(T*, size_t, size_t);
public:
	Merge_Sorter(T*);
	void run();
};

template<typename T>
class Quick_Sorter : public Sorter<T> {
	static size_t partition(T*, size_t, size_t);
	static void quick_sort(T*, size_t, size_t);
public:
	Quick_Sorter(T*);
	void run();
};

template<typename T, typename Decider>
class Hybrid_Sorter : public Sorter<T> {
	//The decider object encapsulates all the state and logic necessary to make a decision about which algorithm to use
	//It is required to have a .tell method that returns an integer from 0 to 3 that signifies which algorithm to use
	Decider decider;
public :
	Hybrid_Sorter(T*, const Decider&);
	void run();
};






/* 
	Implementations :
*/
/////////////////////////////////////
////////////////////////////////////
///////////////////////////////////
/////////////////////////////////////
////////////////////////////////////
///////////////////////////////////
/////////////////////////////////////
////////////////////////////////////
///////////////////////////////////

template<typename Random_Access_Container>
inline Sorter<Random_Access_Container>::Sorter(Random_Access_Container* list)
{
	this->list = list;
}

/////////////////////////////////////
////////////////////////////////////
///////////////////////////////////

template<typename T>
inline Insertion_Sorter<T>::Insertion_Sorter(T* list) : Sorter<T>::Sorter(list)
{
}

template<typename T>
inline void Insertion_Sorter<T>::run()
{
	//Pointless alias to please Visual studio
	auto list = this->list;

	for (size_t i = 1; i < list->size(); i++) {
		size_t j = i;
		while ( (j > 0) && ( (*list)[j] < (*list)[j-1] )  )
		{
			auto temp      = (*list)[j]		;
			(*list)[j]     = (*list)[j - 1] ;
			(*list)[j - 1] = temp			;
			j--;
		}
	}
}
/////////////////////////////////////
////////////////////////////////////
///////////////////////////////////

template<typename T>
inline Selection_Sorter<T>::Selection_Sorter(T* list) : Sorter<T>::Sorter(list)
{
}

template<typename T>
inline void Selection_Sorter<T>::run()
{
	auto list = this->list;

	for (size_t i = 0; i < list->size(); i++) {
		size_t minimum_elem_idx = i;

		for (size_t j = i+1; j < list->size() ; j++) {
			if ( (*list)[j] < (*list)[minimum_elem_idx] ) minimum_elem_idx = j;
		}

		//to avoid unncessary copying for a nearly sorted array
		if (i != minimum_elem_idx) {
			auto temp                 = (*list)[i];
			(*list)[i]				  = (*list)[minimum_elem_idx];
			(*list)[minimum_elem_idx] = temp;
		}
	}
}
/////////////////////////////////////
////////////////////////////////////
///////////////////////////////////

template<typename T>
inline void Merge_Sorter<T>::merge_sort(T* list, size_t start, size_t end)
{
	//Base cases :
	//1-) one element arrays are trivially sorted 
	if (start == end) return;
	//2-) two element arrays can be sorted using one comparison
	if (end == start + 1) {
		if ((*list)[end] < (*list)[start]) {
			auto temp		= (*list)[end];
			(*list)[end]	= (*list)[start];
			(*list)[start]	= temp;
		}
		return;
	}

	//Else recursively sort the two subarrays from start to middle and from middle to end then merge them into a sorted arrays
	size_t mid = (start + end) / 2;
	merge_sort(list, start, mid);
	merge_sort(list, mid + 1, end);

	typedef T::value_type object_t;
	object_t* temp_arr = new object_t[end - start + 1];

	size_t first_sorted_sublist_idx = start ;
	size_t second_sorted_sublist_idx = mid + 1;
	size_t current_available_pos_idx = 0;

	while ( (first_sorted_sublist_idx < (mid+1)) && (second_sorted_sublist_idx < (end+1)) )
	{
		if ( (*list)[first_sorted_sublist_idx] <= (*list)[second_sorted_sublist_idx] ) {
			temp_arr[current_available_pos_idx] = (*list)[first_sorted_sublist_idx];
			first_sorted_sublist_idx++;
		}
		else {
			temp_arr[current_available_pos_idx] = (*list)[second_sorted_sublist_idx];
			second_sorted_sublist_idx++;
		}
		current_available_pos_idx++;
	}

	while (first_sorted_sublist_idx < (mid + 1)) {
		temp_arr[current_available_pos_idx] = (*list)[first_sorted_sublist_idx];
		first_sorted_sublist_idx++;
		current_available_pos_idx++;
	}

	while (second_sorted_sublist_idx < (end + 1)) {
		temp_arr[current_available_pos_idx] = (*list)[second_sorted_sublist_idx];
		second_sorted_sublist_idx++;
		current_available_pos_idx++;
	}

	size_t current_temp_idx = 0;
	for (size_t i = start; i < end + 1; i++) {
		(*list)[i] = temp_arr[current_temp_idx];
		current_temp_idx++;
	}

	//Forget this and you would have the biggest memory leak in recorded computer history haha
	delete[] temp_arr;
}

template<typename T>
inline Merge_Sorter<T>::Merge_Sorter(T* list) : Sorter<T>::Sorter(list)
{
}

template<typename T>
inline void Merge_Sorter<T>::run()
{
	merge_sort(this->list, 0, this->list->size() - 1);
}
/////////////////////////////////////
////////////////////////////////////
///////////////////////////////////

template<typename T>
inline size_t Quick_Sorter<T>::partition(T* list, size_t lo, size_t hi)
{
	//random pivot selection, could be replaced with any formula that gives a number between lo and hi inclusive
	size_t pivot_idx = (rand() % (hi - lo + 1)) + lo ; //rand() % (hi - lo +1) gives a number in range 0->hi-lo , adding lo shifts it to range lo->hi
	auto pivot = (*list)[pivot_idx];
	(*list)[pivot_idx] = (*list)[hi];
	(*list)[hi] = pivot;


	size_t pivot_final_pos = lo;
	for (size_t j = lo; j < hi; j++) {
		if ( (*list)[j] <= pivot ) {
			auto temp  = (*list)[pivot_final_pos] ;
			(*list)[pivot_final_pos] = (*list)[j] ;
			(*list)[j] = temp       ;
			pivot_final_pos++;
		}
	}

	auto temp                 = (*list)[hi];
	(*list)[hi]               = (*list)[pivot_final_pos];
	(*list)[pivot_final_pos] = temp;

	return pivot_final_pos;

}

template<typename T>
inline void Quick_Sorter<T>::quick_sort(T* list, size_t lo, size_t hi)
{
	if (lo < hi) {
		size_t final_pivot_pos = partition(list, lo, hi);

		if(final_pivot_pos != 0)    quick_sort(list, lo, final_pivot_pos - 1);

		if(final_pivot_pos != hi) 	quick_sort(list, final_pivot_pos + 1, hi);
	}
}

template<typename T>
inline Quick_Sorter<T>::Quick_Sorter(T* list) : Sorter<T>::Sorter(list)
{
}

template<typename T>
inline void Quick_Sorter<T>::run()
{
	quick_sort(this->list, 0, this->list->size() - 1);
}
/////////////////////////////////////
////////////////////////////////////
///////////////////////////////////

template<typename T, typename Decider>
inline Hybrid_Sorter<T, Decider>::Hybrid_Sorter(T* list, const Decider& dec) : Sorter<T>::Sorter(list)
{
	decider = dec;
}

template<typename T, typename Decider>
inline void Hybrid_Sorter<T, Decider>::run()
{
	Sorter<T>* servant = nullptr ;
	switch (decider.tell()) {
		case 0 :
			servant = new Selection_Sorter<T>(this->list);
			break ;
		case 1 :
			servant = new Insertion_Sorter<T>(this->list);
			break;
		case 2 :
			servant = new Merge_Sorter<T>(this->list);
			break;
		case 3 :
			servant = new Quick_Sorter<T>(this->list);
			break;

		default: return ;
	}

	servant->run();
	delete servant;
}

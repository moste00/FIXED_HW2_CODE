#pragma once
#include <chrono>
using std::chrono::high_resolution_clock;
using std::chrono::milliseconds;
using std::chrono::duration_cast;

//Any class whose name ends with "er" is a behaviour class, it doesn't own any data and it's sole purpose is to encapsulate behaviour (i.e: functions)
template<typename T>
class Benchmarker
{
public:
	static int benchmark(T*);
};

//Takes a pointer code object that has a .run method
//The benchmarker doesn't own this object, the external world is responsible for ensuring the pointer it holds is a valid 
//Code object
template<typename T>
inline int Benchmarker<T>::benchmark(T* code)
{
	auto before = high_resolution_clock::now() ;
	code->run();
	auto after = high_resolution_clock::now()  ;

	milliseconds t = duration_cast<milliseconds>(after - before);
	return t.count() ; 
}

#include <fstream>
#include <vector>
#include <string>
#include "Sorter.h"
#include "Benchmarker.h"

using std::ifstream;
using std::ofstream;
using std::vector;

typedef vector<int> list_t;

//This is the code object that holds the logic and the statistics necessary to decide which algorithm gets used for which input data
//See the Hybrid_Sorter implementation for more detail
struct decider_t {
	int sizeOfData;

	//A measure of how much the data in the list is nearly sorted
	//It's incremented every time an element A[j] > A[i] with j > i is found
	//It's decremented every time the reverse is true
	int sorting_measure;

	int tell() {
		//If array is already sorted, do not try to sort it
		if (sorting_measure == sizeOfData) return INT_MAX;

		//else quick sort
		return 3 ;
	}
};

list_t* read_elements(const char* input_path, decider_t& decider);

int main(int argc , char* argv[]) {
	srand(time(NULL));
	decider_t decider;
	//Input function takes the decider by reference to populate it with statistics about the data as it reads them
	list_t* elements = read_elements(argv[2],decider);
	Sorter<list_t>* sorting_algo = nullptr;

	switch (argv[1][0])
	{
	case '0':
		sorting_algo = new Selection_Sorter<list_t>(elements);
		break;

	case '1':
		sorting_algo = new Insertion_Sorter<list_t>(elements);
		break;

	case '2':
		sorting_algo = new Merge_Sorter<list_t>(elements);
		break;

	case '3':
		sorting_algo = new Quick_Sorter<list_t>(elements);
		break;

	case '4':
		sorting_algo = new Hybrid_Sorter<list_t, decider_t>(elements,decider);
		break;
	default: 
		break;
	}

	ofstream time_taken_outputfile(argv[4]);
	time_taken_outputfile << Benchmarker<Sorter<list_t>>::benchmark(sorting_algo) ; 
	delete sorting_algo;

	ofstream sorted_data_outputfile(argv[3]);
	for (auto elem : *elements) sorted_data_outputfile << elem << "\n";
	return 0;
}


vector<int>* read_elements(const char* input_path, decider_t& decider)
{
	vector<int>* result = new vector<int>;
	decider.sorting_measure = 0;

	ifstream file(input_path);
	std::string current_line;
	int prev_num = INT_MIN;
	while (getline(file, current_line)) {
		int num = std::stoi(current_line);
		if (num >= prev_num) decider.sorting_measure++;
		prev_num = num;

		result->push_back(num);
	}
	file.close();
	
	decider.sizeOfData = result->size();
	return result;
}



